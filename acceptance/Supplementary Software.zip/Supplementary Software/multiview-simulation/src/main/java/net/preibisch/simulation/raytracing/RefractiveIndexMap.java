package net.preibisch.simulation.raytracing;

public interface RefractiveIndexMap
{
	public double getRI( final double intensity );
}
