[![](https://travis-ci.org/PreibischLab/BigStitcher.svg?branch=master)](https://travis-ci.org/PreibischLab/BigStitcher)

