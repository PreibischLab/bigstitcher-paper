package net.preibisch.stitcher.gui.bdv;

public interface BDVVisibilityHandler
{
	public void updateBDV();
}
